Taiwo follow all this process carefully, when I was typing this I havent designed the admin panel, so
i might send it to you later.

Use <span></span> to select any item you want to program.

I will explain page by page.

Note: aside form emails any string document you will be typing that will display to d users ensure that the first letter is capitalized

1. Change page.

After the user input account information, prompt the change button to replace the old account details in the database 
with the new details.

2 Contact page

a.Esure the user cannot submit without filling phone number and email and your message. make the document upload optional
but the rest compulsory.

b.When the user clicks send message, I want the admin to receive the message on his email,and an alert on his sim that a message as been sent to the his email.

3.Feedback page

no php

4. feedback1 page

no php

5. gh/ghc/ghcc page

a. After registeration i want you to pair the user automatically to whom he is going to pay to, I want you to make sure that the user can never
be paired to the person that refered him/her to the platform.

b. I want you to hide the unpaid button

c. After paring I want a count down to begin from 6 hours downwards, after 6 hours is complete i want you to make the unpaid button visible.

Note: Only a maximum of two people can be paired to all user.(There are some that can recieve more than 2 dey are special, i will explain later)

d. once a person registers i want the program to pair an existing user to the person that newly registered, and I want all the details of the existing user 
to be sent to the "gh" page of the new user.

Note: all users can be paired to only the number people dey refered using their link or phone number. that is if i bring 1 person
 i can only be paired to one person, if i bring 2 i can only be paired to 2 etc. and nobody should pay to the person that referred them. 

e. please ensure that after after paring the first user, 6 other people have to be paired before that user can get 
   a second paring. that is after recieving ur first pair, 6 other people must be paired then you will recieve your second
   (the number of people you bring will determine the number of people that you will be paired to). 

f.once the paid( followed by "yes" in the next page) button is 
clicked ensure that the the person who paid the money should be in queue for payment and payment status should change to paid.

g. if the unpaid button(followed by no in the next page) is clicked, do not delete, only deactivate the user that did not pay. that means block the persons account and pair a new person to the
person that is to recieve payment. please ensure you replace the old persons details with the details of the new person that is paired.
immedately that person clicks unpaid, before a new person is paired, change the Current status in the table to "blocked" .


6 index page

I want the details of the last 5 people that joined to be displayed on the table, ensure that as new people join they replace the old ones.

7 password page
 i want the password to be sent to the email and phone number of the user.

8. ph page
no php

9.profile page
a. i want the number of users that registered with the account owners refereral link to be displayed.(u will c d slot)
b. i want you to generate invite link for all users.
c.the invite link should link to registeration page. and the phone number of the owner of the link should be displayed in "referer phone number" form 
in the register page.
d. display the user details inside the table.
e. below dash board you will see a name juwon omojo, replace it with the name of the account owner.

10 register page.
collect all the details and create an account, distribute the details to where they should be

11. sign in

collect the info and sign in the user.

contact me if you do not understand anything, if am not with the phone message me on facebook and in my email. i will c it.

3 days!!!!!!!!

